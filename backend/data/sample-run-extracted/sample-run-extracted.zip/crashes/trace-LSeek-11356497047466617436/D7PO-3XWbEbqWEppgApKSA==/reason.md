Reason
======

Trace Difference Found
----------------------

Different traces for operation #87:

```json
{"Failure":{"operation":"LSEEK","subcall":"lseek","return_code":-1,"errno":22,"strerror":"Invalid argument"}}
{"Success":{"operation":"LSEEK","return_code":32768,"execution_time":0,"extra":{"hash":null,"timestamps":[]}}}
```

