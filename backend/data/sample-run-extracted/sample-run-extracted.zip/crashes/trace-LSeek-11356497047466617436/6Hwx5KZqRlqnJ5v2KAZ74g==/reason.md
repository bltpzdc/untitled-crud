Reason
======

Trace Difference Found
----------------------

Different traces for operation #7:

```json
{"Failure":{"operation":"LSEEK","subcall":"lseek","return_code":-1,"errno":22,"strerror":"Invalid argument"}}
{"Success":{"operation":"LSEEK","return_code":64,"execution_time":1,"extra":{"hash":null,"timestamps":[]}}}
```

